# Setup
- Download this project
- Setup `ayarlar.json` file
- Open console
- Write `npm i`
- Write `node index.js`

- Your bot is ready
